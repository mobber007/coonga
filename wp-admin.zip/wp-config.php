<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'insiderl_wp1');

/** MySQL database username */
define('DB_USER', 'insiderl_wp1');

/** MySQL database password */
define('DB_PASSWORD', 'C^1(agI^HbZrOs@xi&#95[.9');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'oBgLpXLj1d0WWfmtapx2f8yjAW4Vf6hBD4vNAwwUrx1AsVerAk7JNaCIRHiRUR03');
define('SECURE_AUTH_KEY',  '3vT60e67DPTre23XK79tLCW6XwcKJrkBEMEei28AoYheV2couWipuGJzat4dyRlb');
define('LOGGED_IN_KEY',    'HuotfdDk92yM4J78PbShVHx3Tv2jAunboAOlex3gZYrucsOt0xsNAZMy2b0ARFzV');
define('NONCE_KEY',        'WNrHrnGFOfQToTtcyLDB7EP1vFwiIQGu2HN0IGydIJy54FnGZw4WzYyufIF5CUcP');
define('AUTH_SALT',        'zx7U9h0xmfVh9azEeEU01ggsDEfo6zPl4dmyiTdrmbJGRNfTaGAsDkk3DbGAbGxa');
define('SECURE_AUTH_SALT', 'OugRQ2qCcUhZUaMJCCSgXgp5nLSTusN7kBbarqgFgf9cfBUPaBjkSAa3ZmF9Ipvq');
define('LOGGED_IN_SALT',   'j12V18RUho7QQCcNU5NH5O3ZU2TfbJlqgVQx6xY6VC7mKI89FujbZF436OySsu6j');
define('NONCE_SALT',       'QP05crSf1AF0vPVN74doFYuK81Nc1HfrIog1bcQxsMQyPraRITnbRyskkMovjmmI');

/**
 * Other customizations.
 */
define('FS_METHOD','direct');define('FS_CHMOD_DIR',0755);define('FS_CHMOD_FILE',0644);
define('WP_TEMP_DIR',dirname(__FILE__).'/wp-content/uploads');

/**
 * Turn off automatic updates since these are managed upstream.
 */
define('AUTOMATIC_UPDATER_DISABLED', true);

/**
 * Multi-site
 *
 */
define('MULTISITE', true);
define('SUBDOMAIN_INSTALL', false);
$base = '/';
define('DOMAIN_CURRENT_SITE', 'curiouslads.com');
define('PATH_CURRENT_SITE', '/');
define('SITE_ID_CURRENT_SITE', 1);
define('BLOG_ID_CURRENT_SITE', 1);
define('WP_ALLOW_MULTISITE', true);


/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
